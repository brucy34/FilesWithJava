package core;

import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.*;

public class PlayBook {
    public static void copy(File src,File dest) throws IOException {
        if (src.isDirectory()) {

            if (!dest.exists()) {
                dest.mkdir();
                System.out.println("Dossier cree");
            }
            //lister le contenu du répertoire
            String files[] = src.list();

            for (String f : files) {
                //construire la structure des fichiers src et dest
                File srcF = new File(src, f);
                File destF = new File(dest, f);
                //copie récursive
                copy(srcF, destF);
            }
        }
        else{
            //si src est un fichier, copiez-le.
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];
            int length;
            //copier le contenu du fichier
            while ((length = in.read(buffer)) > 0){
                out.write(buffer, 0, length);
            }

            in.close();
            out.close();
            System.out.println("Fichier copie");
        }

    }
    public static void main(String[] args)
    {
        String pathSource,pathDest;
        Scanner scan=new Scanner(System.in);
        System.out.println("Veuillez entrez le path du dossier que vous voulez copier");
        pathSource=scan.nextLine();
        System.out.println("Veuillez entrez le path du dossier destinateur");
        pathDest=scan.nextLine();

        File apath1=new File(pathSource);
        File apath2=new File(pathDest);
        try {
            copy(apath1,apath2);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
