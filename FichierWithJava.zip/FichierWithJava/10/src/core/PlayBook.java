package core;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class PlayBook {
    public static void main(String[] args) throws IOException {
        String oldPath,newPath;
        Scanner scan=new Scanner(System.in);
        System.out.println("Veuillez entrer le path du fichier/dossier que vous voulez deplacer");
        oldPath=scan.nextLine();
        System.out.println("Veuillez entrer le nouveau path(contenant le fichier/dossier que vous voulez deplacer)");
        newPath=scan.nextLine();



            Path temp= Files.move(Paths.get(oldPath),Paths.get(newPath));

            if(temp != null)
                System.out.println("Deplace avec succes");
            else
                System.out.println("Impossible a deplacer");

    }
}
