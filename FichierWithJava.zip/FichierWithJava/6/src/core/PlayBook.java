package core;

import java.io.File;
import java.util.Scanner;

public class PlayBook {
    public static void main(String[] args)
    {
        String path;
        System.out.println("Veuillez entrer la path du fichier que vous voulez supprimer(le fichier doit etre vide)");
        Scanner scan= new Scanner(System.in);
        path=scan.nextLine();

        File apath=new File(path);
        if(apath.isFile())
        {
            if(apath.length()==0) {
                apath.delete();
                System.out.println("Supprime avec succes");
            }
            else
                System.out.println("Le fichier n'est pas vide");
        }
    }
}
