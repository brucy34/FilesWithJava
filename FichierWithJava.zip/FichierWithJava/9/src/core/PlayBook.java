package core;

import java.io.File;
import java.util.Scanner;

public class PlayBook {
    public static void main(String[] args)
    {
        String path,newName;
        Scanner scan=new Scanner(System.in);
        System.out.println("Veuillez entrez le path complet du fichier/dossier que vous voulez renommer");
        path=scan.nextLine();
        System.out.println("Veuillez entrer le path avec le nouveau nom");
        newName=scan.nextLine();

        File apath=new File(path);
        File apath1=new File(newName);

        if(apath.exists())
        {
            if(apath.renameTo(apath1))
                System.out.println("renomme avec succes");
            else
                System.out.println("Impossible a renommer");
        }
        else
            System.out.println("Le fichier n'existe pas");
    }
}
