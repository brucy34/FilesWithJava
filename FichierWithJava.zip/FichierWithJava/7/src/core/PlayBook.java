package core;

import java.io.File;
import java.util.Scanner;

public class PlayBook {
    public static void main(String[] args)
    {
        String path;
        System.out.println("Veuillez entrez le path complet du repertoire que vous voulez supprimer");
        Scanner scan=new Scanner(System.in);
        path=scan.nextLine();

        File apath= new File(path);

        if(apath.exists()) {
            if (apath.length() == 0) {
                apath.delete();
                System.out.println("Dossier supprime");
            } else {
                File[] liste = apath.listFiles();
                for (File item : liste) {
                    if (item.isFile()) {
                        item.delete();
                        System.out.format("Fichier supprime\n");
                    }
                }
                apath.delete();
                System.out.println("Dossier supprime");
            }
        }
        else
            System.out.println("Le path que vous avez saisi est incorrect");
    }
}
