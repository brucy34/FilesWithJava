package core;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class PLAYBOOK
{
    public static void main(String []argv){
        String file;
        System.out.println("Entrez le path complet du fichier que vous voulez creer");
        Scanner scan= new Scanner(System.in);
        file= scan.nextLine();

        File apath1 = new File(file);

        if(!apath1.exists()) {
            try {
                apath1.createNewFile();
                System.out.println("Fichier cree avec succes");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else
            System.out.println("Le fichier existe  deja");

    }
}
