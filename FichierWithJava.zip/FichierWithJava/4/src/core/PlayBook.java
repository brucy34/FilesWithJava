package core;

import java.io.File;
import java.util.Scanner;

public class PlayBook {
    public static void main(String[]args)
    {
        String path;
        System.out.println("Veuillez entrez le path complet du repertoire que vous voulez analyser");
        Scanner scan=new Scanner(System.in);
        path=scan.nextLine();

        File apath= new File(path);

        if(apath.exists())
        {
            File[] liste = apath.listFiles();
            for(File item : liste){
                if(item.isDirectory())
                {
                    System.out.format("Nom du répertoire: %s%n", item.getName());
                }
            }
        }
        else
            System.out.println("Le path que vous avez saisi est incorrect");
    }
}
